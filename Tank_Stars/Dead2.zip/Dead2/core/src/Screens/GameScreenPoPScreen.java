package Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Dialog;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.stars.game.MarioBros;
import sun.jvm.hotspot.utilities.ObjectReader;

import javax.security.sasl.SaslClient;


public class GameScreenPoPScreen extends ScreenAdapter {
    private MarioBros game;
    private Stage stage;
    private Skin skin ;
    private OrthographicCamera camera;
    private FitViewport gameport;
    private ResumeMenu dialog;

    public static class ResumeMenu extends Dialog{
        public ResumeMenu(String title, Skin skin) {
            super(title, skin);
        }

        public ResumeMenu(String title, Skin skin, String windowStyleName) {
            super(title, skin, windowStyleName);
        }

        public ResumeMenu(String title, WindowStyle windowStyle) {
            super(title, windowStyle);
        }

        {
            text("ARE YOU SURE ?");
            button("SAVE GAME");
            button("EXIT");
            button("RESUME");
        }

        @Override
        protected void result(Object object) {
            super.result(object);
        }
    }




    public void show(MarioBros Game) {
        this.game = Game;
        camera = game.factory.getOrthographicCamera();
        gameport = game.factory.getFitViewport(camera);
        skin = game.factory.getSkin("skin/glassy-ui.json");
        stage = game.factory.getStage(gameport,game.batch);
        dialog = new ResumeMenu("RESUME",skin);
        dialog.show(stage);
    }
    @Override
    public void show(){

    }

    @Override
    public void render(float v) {
        ScreenUtils.clear(0, 0, 0, 0);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        camera.update();
        game.batch.setProjectionMatrix(camera.combined);
    }

    @Override
    public void resize(int i, int i1) {
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
