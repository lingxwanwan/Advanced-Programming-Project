package Screens;

import java.io.*;

public class saver_class implements Serializable {
    oneVoneGameScreen gameScreen ;
    public saver_class(oneVoneGameScreen gameScreen){
        this.gameScreen = gameScreen;
    }
    public void setGameScreen(oneVoneGameScreen gameScreen){
        this.gameScreen = gameScreen;
    }
    public oneVoneGameScreen load(){

        try{
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("save.txt"));
            return (oneVoneGameScreen) in.readObject();
        }
        catch (Exception e){
            System.out.println(e.getMessage());
            System.out.println("69");
        }
        return null;
    }


    public void save()  {
        try{
            FileOutputStream saved = new FileOutputStream("save.txt");
            ObjectOutputStream currentGame = new ObjectOutputStream(saved);
            currentGame.writeObject(gameScreen);
        }
        catch (IOException e){
            System.out.println(e.getMessage());
        }


    }

}
