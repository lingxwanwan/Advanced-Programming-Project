package Screens;

import GamePlay.Tanks;
import java.io.*;

import GamePlay.Trajectory;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.stars.game.MarioBros;

import javax.swing.text.Position;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;

public class oneVoneGameScreen implements Screen/*, Serializable*/ {
    private final MarioBros game;
    private final TmxMapLoader mapLoader;
    private final TiledMap map;
    private final OrthographicCamera camera;
    private final OrthogonalTiledMapRenderer renderer;
    private final Viewport gamePort;
    public  Stage stage; //
    private final World world;
    private final Box2DDebugRenderer b2dr;
    private final Texture PauseImage;
    private final Drawable drawablePauseImage;
    private final TextureRegion PauseImageRegion;
    private final ImageButton PauseButton;
    private final Body bodyFirstPlayerTank; //
    private final Body bodySecondPlayerTank;//

    private Texture MissileImage;
    private Body body;
    private final Sprite sprite1;  //
    private final Sprite sprite2;  //
    private final TextButton FireButton;
    private final Skin skin;
    private final Table table; //
    private Boolean flagRight1 = true;    //
    private Boolean flagLeft1 = false;   //
    private Boolean flagRight2 = true;   //
    private Boolean flagLeft2 = false;   //
    private Boolean flagFire = false;  //

    private Boolean flagFireVisited = false; //
    private Boolean FirstPlayerControlFlag = true;  //
    private Boolean SecondPlayerContrlFlag = false;  //
    public static Boolean WeaponGroundHit = false;  //
    private static Body weapon;
    private static Fixture weaponfixture;
    private Texture[] HealthBarPlayer1; // SIZE IS TWO ONE FOR BACKGROUND  //
    private Texture[] HealthBarPlayer2; //
    private Texture[] FuelBarPlayer1;  //
    private Texture[] FuelBarPlayer2;  //
    int i = 10;
    private FixtureDef fd;  //

    private saver_class saverClass;  //

    public static Boolean WeaponTankHit = false;

    public oneVoneGameScreen(MarioBros Game) {
        this.game = Game;
        camera = game.factory.getOrthographicCamera();
        gamePort = game.factory.getFitViewport(camera);
        stage = game.factory.getStage((FitViewport) gamePort, game.batch);
        mapLoader = new TmxMapLoader();
        map = mapLoader.load("World.tmx");
        skin = game.factory.getSkin("skin/glassy-ui.json");

        FireButton = new TextButton("FIRE", skin, "small");
        table = game.factory.getTable();
        table.add(FireButton).width(200).height(100);
        table.setPosition(1100, 300);
        stage.addActor(table);

        fd = new FixtureDef();
        fd.density = 5;
        fd.restitution = 0;
        world = game.factory.getWorld();


        //rect.setAsBox(5,5);
        //fd.shape = rect;

        HealthBarPlayer1 = game.factory.createHealthBar();
        HealthBarPlayer2 = game.factory.createHealthBar();

        FuelBarPlayer1 = game.factory.createFuelBar();
        FuelBarPlayer2 = game.factory.createFuelBar();


        PauseImage = game.factory.getTexture("pause.png");
        PauseImageRegion = new TextureRegion(PauseImage);
        drawablePauseImage = new TextureRegionDrawable(new TextureRegion(PauseImageRegion));


        PauseButton = new ImageButton(drawablePauseImage);
        PauseButton.setPosition(1, gamePort.getWorldHeight() - 70);
        PauseButton.setSize(50, 50);
        stage.addActor(PauseButton);
        Gdx.input.setInputProcessor(stage);
        sprite1 = game.factory.getSprite(game.FirstPlayer.getTanks().tankImage);
        //sprite1 = new Sprite(game.FirstPlayer.getTanks().tankImage);
        sprite2 = game.factory.getSprite(game.SecondPlayer.getTanks().tankImage);
        //sprite2 = new Sprite(game.SecondPlayer.getTanks().tankImage);
        renderer = new OrthogonalTiledMapRenderer(map);
        camera.setToOrtho(false, gamePort.getWorldWidth() / 2, gamePort.getWorldHeight() / 2);
        camera.position.set(gamePort.getWorldWidth() / 2, gamePort.getWorldHeight() / 2, 0);

        b2dr = game.factory.getBox2DDebugRenderer();

        BodyDef bdef = new BodyDef();
        FixtureDef fdef = new FixtureDef();
        fdef.friction = 0.5f;

        bodyFirstPlayerTank = game.factory.getWorldBody("Tank", world, 300, 350);
        bodySecondPlayerTank = game.factory.getWorldBody("Tank", world, 900, 450);


        for (MapObject object : map.getLayers().get(1).getObjects()) {

            Shape shape = getRectangle((RectangleMapObject) object);
            bdef.type = BodyDef.BodyType.StaticBody;
            body = world.createBody(bdef);
            fdef.shape = shape;
            fdef.restitution = 0;
            Fixture fixture = body.createFixture(fdef);
            fixture.setUserData("Ground");
        }
        world.setContactListener(new WorldContactListener());
    }

    private static PolygonShape getRectangle(RectangleMapObject rectangleObject) {
        Rectangle rectangle = rectangleObject.getRectangle();
        PolygonShape polygon = new PolygonShape();
        Vector2 size = new Vector2((rectangle.x + rectangle.width * 0.5f),
                (rectangle.y + rectangle.height * 0.5f));
        polygon.setAsBox(rectangle.width * 0.5f, rectangle.height * 0.5f, size, 0.0f);
        return polygon;
    }

    @Override
    public void show() {

    }

    public void update(float dt) {
        world.step((1 / 60f)*1.5f, 6, 2);
        camera.update();
        renderer.setView(camera);
    }

    public void handleinput(float delta) {
        if (flagFire && !flagFireVisited) {
            //game.ClickSound.play();
            flagFireVisited = true;
            BodyDef bdefn = new BodyDef();
            bdefn.type = BodyDef.BodyType.DynamicBody;
            if (FirstPlayerControlFlag) {
                bdefn.position.set(bodyFirstPlayerTank.getPosition().x, bodyFirstPlayerTank.getPosition().y + 5);
            } else {
                bdefn.position.set(bodySecondPlayerTank.getPosition().x, bodySecondPlayerTank.getPosition().y + 5);
            }
            weapon = world.createBody(bdefn);

            PolygonShape rect = new PolygonShape();
            rect.setAsBox(1, 1);
            fd.shape = rect;

            weaponfixture = weapon.createFixture(fd);
            weaponfixture.setUserData("weapon");

            if (game.FirstPlayer.getTanks().Fuel==0 || game.SecondPlayer.getTanks().Fuel==0){
                game.setScreen(new oneVone_Selection_Screen(game));
            }



            if (FirstPlayerControlFlag) {
                //weapon.applyLinearImpulse(new Vector2(Trajectory.FirstPlayerpower*10, Trajectory.FirstPlayerpower*10), weapon.getWorldCenter(), true);
                weapon.setLinearVelocity(Trajectory.FirstPlayerpower*((float)Math.cos((3.14*Trajectory.FirstPlayerangle)/180))*10,10*Trajectory.FirstPlayerpower*((float)Math.sin((3.14*Trajectory.FirstPlayerangle)/180)));

                //weapon.setLinearVelocity(new Vector2(Trajectory.FirstPlayerpower*((float)Math.cos((3.14*Trajectory.FirstPlayerangle)/180))*10,10*Trajectory.FirstPlayerpower*((float)Math.sin((3.14*Trajectory.FirstPlayerangle)/180))));
                MissileImage = game.FirstPlayer.getTanks().CurrentWeapon.getweaponImage();
            } else if (SecondPlayerContrlFlag) {
                weapon.setLinearVelocity(-Trajectory.SecondPlayerpower*((float)Math.cos((3.14*Trajectory.SecondPlayerangle)/180))*10,10*Trajectory.SecondPlayerpower*((float)Math.sin((3.14*Trajectory.SecondPlayerangle)/180)));

                //weapon.setLinearVelocity(new Vector2(-Trajectory.SecondPlayerpower*((float)Math.cos((3.14*Trajectory.SecondPlayerangle)/180))*10,10*Trajectory.SecondPlayerpower*((float)Math.sin((3.14*Trajectory.SecondPlayerangle)/180))));
                //weapon.applyLinearImpulse(new Vector2(Trajectory.SecondPlayerpower*10, Trajectory.SecondPlayerpower*10), weapon.getWorldCenter(), true);
                MissileImage = game.SecondPlayer.getTanks().CurrentWeapon.getweaponImage();
            }
        }
        if (FirstPlayerControlFlag && game.FirstPlayer.getTanks().getFuel() != 0) {

            if (Gdx.input.isKeyJustPressed(Input.Keys.RIGHT) && bodyFirstPlayerTank.getLinearVelocity().x <= 10) {
                bodyFirstPlayerTank.applyLinearImpulse(new Vector2(25000f, 0), bodyFirstPlayerTank.getWorldCenter(), true);
                if (!flagRight1) {
                    sprite1.flip(true, false);
                    flagRight1 = true;
                    flagLeft1 = false;
                }
                game.FirstPlayer.getTanks().DecFuel(Tanks.AmountToDecFuel);
            }
            if (Gdx.input.isKeyPressed(Input.Keys.LEFT) && bodyFirstPlayerTank.getLinearVelocity().x >= -10) {
                bodyFirstPlayerTank.applyLinearImpulse(new Vector2(-25000f, 0), bodyFirstPlayerTank.getWorldCenter(), true);
                if (!flagLeft1) {
                    sprite1.flip(true, false);
                    flagRight1 = false;
                    flagLeft1 = true;
                }
                game.FirstPlayer.getTanks().DecFuel(Tanks.AmountToDecFuel);
            }
        } else if (SecondPlayerContrlFlag && game.SecondPlayer.getTanks().getFuel() != 0) {

            if (Gdx.input.isKeyJustPressed(Input.Keys.RIGHT) && bodySecondPlayerTank.getLinearVelocity().x <= 10) {
                System.out.println("hi");
                bodySecondPlayerTank.applyLinearImpulse(new Vector2(25000f, 0), bodySecondPlayerTank.getWorldCenter(), true);
                if (!flagRight2) {
                    sprite2.flip(true, false);
                    flagRight2 = true;
                    flagLeft2 = false;
                }
                game.SecondPlayer.getTanks().DecFuel(Tanks.AmountToDecFuel);
            }
            if (Gdx.input.isKeyPressed(Input.Keys.LEFT) && bodySecondPlayerTank.getLinearVelocity().x >= -10) {
                bodySecondPlayerTank.applyLinearImpulse(new Vector2(-25000f, 0), bodySecondPlayerTank.getWorldCenter(), true);
                if (!flagLeft2) {
                    sprite2.flip(true, false);
                    flagRight2 = false;
                    flagLeft2 = true;
                }
                game.SecondPlayer.getTanks().DecFuel(Tanks.AmountToDecFuel);
            }
        }
        if(Gdx.input.isKeyJustPressed(Input.Keys.W)){
            if (FirstPlayerControlFlag){
                if (Trajectory.FirstPlayerpower<=100){
                    Trajectory.FirstPlayerpower++;
                }

            }
            else if (SecondPlayerContrlFlag){
                if (Trajectory.SecondPlayerpower<=100){
                    Trajectory.SecondPlayerpower++;
                }
            }
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.S)){
            if (FirstPlayerControlFlag){
                if (Trajectory.FirstPlayerpower>=50){
                    Trajectory.FirstPlayerpower--;
                }
            }
            else if (SecondPlayerContrlFlag){
                if (Trajectory.SecondPlayerpower>=50){
                    Trajectory.SecondPlayerpower--;
                }

            }
        }

        if(Gdx.input.isKeyJustPressed(Input.Keys.D)){
            if (FirstPlayerControlFlag){
                if (Trajectory.FirstPlayerangle<180){
                    Trajectory.FirstPlayerangle++;
                }

            }
            else if (SecondPlayerContrlFlag){
                if (Trajectory.SecondPlayerangle<180){
                    Trajectory.SecondPlayerangle++;
                }
            }
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.A)){
            if (FirstPlayerControlFlag){
                if (Trajectory.FirstPlayerangle>0){
                    Trajectory.FirstPlayerangle--;
                }

            }
            else if (SecondPlayerContrlFlag){
                if (Trajectory.SecondPlayerangle>0){
                    Trajectory.SecondPlayerangle--;
                }

            }
        }


        FireButton.addListener(new ClickListener() {
            public void clicked(InputEvent event, float x, float y) {
                flagFire = true;
            }
        });
        PauseButton.addListener(new ClickListener() {
            public void clicked(InputEvent event, float x, float y) {
                new Dialog("RESUME", skin) {
                    {

                        button("RESUME", "goodbye");
                        button("SAVE", "SAVE");
                        button("EXIT", "EXIT");
                    }

                    @Override
                    protected void result(Object object) {
                        if (((String) object).equals("EXIT")) {
                            game.setScreen(new oneVone_Selection_Screen(game));
                        }
                        else if (((String)object).equals("SAVE")){
                            Saver();
                        }
                    }
                }.show(stage);
            }
        });
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.batch.setProjectionMatrix(camera.combined);
        renderer.render();
        b2dr.render(world, camera.combined);
        game.batch.begin();
        game.batch.draw(sprite1, game.FirstPlayer.update(bodyFirstPlayerTank).get(0), game.FirstPlayer.update(bodyFirstPlayerTank).get(1), 50, 50);
        game.batch.draw(sprite2, game.SecondPlayer.update(bodySecondPlayerTank).get(0), game.SecondPlayer.update(bodySecondPlayerTank).get(1), 50, 50);

        game.batch.draw(HealthBarPlayer1[0], 200, 600, 400, 21);
        game.font.draw(game.batch, "Player1 Health", 210, 600);
        game.font.draw(game.batch, "Player2 Health", 700, 600);
        game.batch.draw(HealthBarPlayer1[1], 200, 600, game.FirstPlayer.getHealth(), 21);
        game.batch.setColor(Color.WHITE);
        game.batch.draw(HealthBarPlayer2[0], 700, 600, 400, 21);
        game.batch.draw(HealthBarPlayer2[1], 700, 600, game.SecondPlayer.getHealth(), 21);

        handleinput(delta);  // DO NOT REMOVE
        if (FirstPlayerControlFlag) {
            game.batch.draw(FuelBarPlayer1[0], 200, 200, 200, 25);
            game.batch.draw(FuelBarPlayer1[1], 200, 200, game.FirstPlayer.getTanks().getFuel(), 25);
            game.font.draw(game.batch, "Fuel", 210, 200);
            game.font.draw(game.batch,"Power : "+ Trajectory.FirstPlayerpower,210,180);
            game.font.draw(game.batch,"Angle : "+Trajectory.FirstPlayerangle,210,160);
        } else if (SecondPlayerContrlFlag) {
            game.batch.draw(FuelBarPlayer2[0], 1000, 200, 200, 25);
            game.batch.draw(FuelBarPlayer2[1], 1000, 200, game.SecondPlayer.getTanks().getFuel(), 25);
            game.font.draw(game.batch, "Fuel", 1000, 200);
            game.font.draw(game.batch,"Power : "+ Trajectory.SecondPlayerpower,1000,180);
            game.font.draw(game.batch,"Angle : "+Trajectory.SecondPlayerangle,1000,160);
        }
        if (flagFire && flagFireVisited) {
            game.batch.draw(MissileImage, weapon.getPosition().x - 1, weapon.getPosition().y - 1, 30, 30);
        }


        update(delta);// ;



        if (WeaponGroundHit) {
            WeaponGroundHit = false;
            if (Math.abs(bodyFirstPlayerTank.getPosition().x-weapon.getPosition().x)<=10 || Math.abs(bodyFirstPlayerTank.getPosition().y-weapon.getPosition().y)<=10){
                System.out.println("Hi");
                game.FirstPlayer.DecHealth(30);
            }
            if (Math.abs(bodySecondPlayerTank.getPosition().x-weapon.getPosition().x)<=10 || Math.abs(bodySecondPlayerTank.getPosition().y-weapon.getPosition().y)<=10){
                System.out.println("hello");
                game.SecondPlayer.DecHealth(30);
            }
            //WeaponGroundHit();

            weapon.destroyFixture(weaponfixture);
            flagFire = false;
            flagFireVisited = false;

            FirstPlayerControlFlag = !FirstPlayerControlFlag;
            SecondPlayerContrlFlag = !SecondPlayerContrlFlag;
            game.FirstPlayer.getTanks().ResetFuel();
            game.SecondPlayer.getTanks().ResetFuel();

            //}
        }
        if (WeaponTankHit){
            WeaponTankHit = false;

            if (!FirstPlayerControlFlag){
                game.FirstPlayer.DecHealth(30);
            }
            else if (!SecondPlayerContrlFlag){
                game.SecondPlayer.DecHealth(30);
            }

            weapon.destroyFixture(weaponfixture);

            flagFire = false;
            flagFireVisited = false;
            FirstPlayerControlFlag = !FirstPlayerControlFlag;
            SecondPlayerContrlFlag = !SecondPlayerContrlFlag;
            game.FirstPlayer.getTanks().ResetFuel();
            game.SecondPlayer.getTanks().ResetFuel();
        }
        game.batch.end();
        stage.draw();
        stage.act();
    }

    @Override
    public void resize(int width, int height) {
        gamePort.update(width, height);

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        map.dispose();
        world.dispose();
        game.FirstPlayer.getTexture().dispose();
    }


    void saving() throws FileNotFoundException {
        FileOutputStream saved = new FileOutputStream("save.txt");
        try {
            ObjectOutputStream current_game = new ObjectOutputStream(saved);
            current_game.writeObject(this);
            current_game.flush();
            current_game.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    void loading() throws FileNotFoundException {
        FileInputStream file = new FileInputStream("save.txt");
        try {
            ObjectInputStream object = new ObjectInputStream(file);
            oneVoneGameScreen loaded_game = (oneVoneGameScreen) object.readObject();

        } catch (Exception e) {
            System.out.println("lol");
        }

    }

    public void Saver() {

        saverClass = new saver_class(this);
        saverClass.save();
    }



}


