package Screens;

import GamePlay.Player;
import GamePlay.Tanks;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.Disableable;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.stars.game.MarioBros;

import java.io.ObjectInputStream;
import java.io.ObjectStreamException;

public class oneVone_Selection_Screen implements Screen {

    private MarioBros game ;
    private int tankIndex ;
    private Skin skin ;


    private Texture BackgroundImg ;
    private Stage stage;
    private TextureRegion BackgroundImgTexture;
    private Texture backImgPic;
    private TextureRegion BackRegion;
    private Drawable drawable ;
    private ImageButton backButton;

    private Texture changeTankPic;
    private Drawable drawableChangeTank;
    private TextureRegion changeTankRegion;
    private ImageButton changeTank;

    private Texture backTankPic;
    private Drawable drawablebackTank;
    private TextureRegion backTankRegion;
    private ImageButton backTank;
    private Boolean flag;
    private Boolean flagBack;
    private Boolean flagChoose;
    private int chooseCount;

    private ImageButton settingsButton;

    private TextButton ChooseButton ;

    private OrthographicCamera camera;
    private Viewport gamePort;
    private Table table;
    private saver_class saver_class;
    public oneVone_Selection_Screen(MarioBros game){
        this.game = game;
        tankIndex = 0;
        skin = new Skin(Gdx.files.internal("skin/glassy-ui.json"));
        camera = new OrthographicCamera();
        gamePort = new FitViewport(1280,663,camera);
        camera.setToOrtho(false, gamePort.getWorldWidth(),gamePort.getWorldHeight());
        stage = new Stage(gamePort, game.batch);
        flag = false;
        flagBack = false;
        flagChoose = false;
        chooseCount = 0;
        table = new Table();

        BackgroundImg = new Texture("HomeMenu_2.jpg");
        BackgroundImgTexture = new TextureRegion(BackgroundImg);

        backButton = game.factory.getImageButton("BackButton_Img.png");
        backButton.setPosition(1,gamePort.getWorldHeight()-70);
        backButton.setSize(50,50);

        changeTank = game.factory.getImageButton("ChangeTankImage.png");

        settingsButton = game.factory.getImageButton("SettingsButton.png");
        settingsButton.setSize(80,50);
        settingsButton.setPosition(710,600);


        backTank = game.factory.getImageButton("backTankImage.png");
        //backTank.setPosition(470,270);
        //backTank.setSize(50,50);



        ChooseButton = new TextButton("CHOOSE",skin,"small");
        ChooseButton.setWidth(300);
        ChooseButton.setHeight(50);
        //ChooseButton.setPosition(470,150);

        table.add(backTank).width(50).height(50).spaceRight(280).spaceBottom(80);
        table.add(changeTank).width(50).height(50).space(0,0,60,0);

        table.row();
        table.add();
        table.row();
        table.add(ChooseButton).width(300).spaceTop(70);

        table.setPosition(350,30);
        table.setFillParent(true);

        stage.addActor(table);
        stage.addActor(backButton);
        stage.addActor(settingsButton);
        Gdx.input.setInputProcessor(stage);
    }
    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 0);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        camera.update();
        game.batch.setProjectionMatrix(camera.combined);
        game.batch.begin();

        game.batch.draw(BackgroundImgTexture,0,0,gamePort.getWorldWidth(),gamePort.getWorldHeight());
        game.font.draw(game.batch, "Select tank for Player1 and Player2", 850, 200);
        int imx = 850;
        int imy = 300;
        if (flag){
            try{
                game.batch.draw(game.tanks.getTanksList().get(++tankIndex).tankImage,imx,imy,imy,imy);
                flag = false;
            }
            catch (Exception e){
                game.batch.draw(game.tanks.getTanksList().get(--tankIndex).tankImage,imx,imy,imy,imy);
                flag = false;
            }
        }
        else if (flagBack){
            try{
                game.batch.draw(game.tanks.getTanksList().get(--tankIndex).tankImage,imx,imy,imy,imy);

                flagBack = false;
            }
            catch (Exception e){
                game.batch.draw(game.tanks.getTanksList().get(++tankIndex).tankImage,imx,imy,imy,imy);
                flagBack = false;
            }
        }
        else{
            game.batch.draw(game.tanks.getTanksList().get(tankIndex).tankImage,imx,imy,imy,imy);
            flag = false;
            flagBack = false;
        }

        game.batch.end();
        stage.draw();

        if (flagChoose){
            Sprite  sprite;
            sprite = new Sprite(game.tanks.getTanksList().get(tankIndex).tankImage);
            sprite.setSize(50,50);
            sprite.setPosition(500,600);
            if (++chooseCount==1){
                System.out.println(tankIndex);
                game.FirstPlayer = new Player((game.tanks.getTanksList().get(tankIndex)));
                System.out.println(game.FirstPlayer.getTanks().Fuel);
                //game.FirstPlayer = game.factory.createPlayer(game.tanks.getTanksList().get(tankIndex).getName());
            }
            else if (chooseCount==2){
                game.SecondPlayer = new Player((game.tanks.getTanksList().get(tankIndex)));
                game.setScreen(new oneVoneGameScreen(game));
                dispose();
            }
            flagChoose = false;
        }

        handleinput(delta);
    }
    void handleinput(float del){
        backButton.addListener(new ClickListener(){
            public void clicked(InputEvent event , float x, float y){
                game.ClickSound.play();
                game.setScreen(new SelectModeScreen(game));
                dispose();
            }
        });
        changeTank.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event ,float x,float y){
                game.ClickSound.play();
                flag  = true;

                //Gdx.graphics.requestRendering();
            }
        });
        backTank.addListener(new ClickListener(){
            public void clicked(InputEvent event ,float x,float y){
                game.ClickSound.play();
                flagBack  = true;
            }
        });
        ChooseButton.addListener(new ClickListener(){
            public void clicked (InputEvent event ,float x,float y){
                game.ClickSound.play();
                flagChoose = true;
            }
        });
        settingsButton.addListener(new ClickListener() {
           public void clicked(InputEvent event,float x,float y){
               /*new Dialog("LOAD SAVED GAMES",skin){
                   {
                       button("SAVE1","SAVE1");
                       button("EXIT","sayGoodBye");
                   }
                   @Override
                   protected void result(Object object){
                       if (((String) object).equals("SAVE1")) {
                           game.setScreen(saver_class.load());
                       }
                   }
               }.show(stage);*/
           }
        });

    }

    @Override
    public void resize(int width, int height) {
        gamePort.update(width, height);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        stage.dispose();

    }
}
