package Box2dObjects;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.FitViewport;

public class Factory {
    private static Boolean FactoryObject = false;
    private Factory(){};
    public static Factory getInstance(){
        if (FactoryObject){
            return null;
        }
        else{
            FactoryObject = true;
            return new Factory();
        }
    }
    public Table getTable(){
        return new Table();
    }
    public Skin getSkin(String Path){
        return new Skin(Gdx.files.internal(Path));
    }
    public OrthographicCamera getOrthographicCamera(){
        return new OrthographicCamera();
    }
    public Stage getStage(FitViewport gamport, SpriteBatch batch){
        return new Stage(gamport,batch);
    }
    public Texture getTexture(String Path){
        return new Texture(Path);
    }
    public Sprite getSprite(Texture texture){
        return new Sprite(texture);
    }
    public FitViewport getFitViewport(OrthographicCamera camera){
        return new FitViewport(1280,663,camera);
    }
    public World getWorld(){
        return new World(new Vector2(0,-20),false);
    }
    public Box2DDebugRenderer getBox2DDebugRenderer(){
        return new Box2DDebugRenderer();
    }
    public BodyDef getBodyDef(){
        return new BodyDef();
    }
    public FixtureDef getFixtureDef(){
        return new FixtureDef();
    }
    public Body getWorldBody(String Name, World world,float x,float y){
        Body body = null;
        if(Name.equals("Tank")){
            BodyDef bd = getBodyDef();
            bd.type = BodyDef.BodyType.DynamicBody;
            bd.position.set(x,y);
            body = world.createBody(bd);

            FixtureDef fd1 = getFixtureDef();

            CircleShape circle = new CircleShape();
            circle.setRadius(10);
            //fd.shape = circle;
            fd1.friction= 100f;
            fd1.restitution = 0;
            fd1.density = 100f;

            PolygonShape rect = new PolygonShape();
            rect.setAsBox(2,2);
            fd1.shape = rect;


            Fixture fixture = body.createFixture(fd1);
            fixture.setUserData("Tank");
        }


        return body;
    }
    public Body createWorldToDeleteBody(World world,FixtureDef fd,float x,float y){
        Body body;
        BodyDef bdefn = new BodyDef();
        bdefn.type = BodyDef.BodyType.DynamicBody;
        bdefn.position.set(x,y);
        body = world.createBody(bdefn);

        PolygonShape rect = new PolygonShape();
        rect.setAsBox(5,5);
        fd.shape = rect;

        Fixture weaponfixture= body.createFixture(fd);
        weaponfixture.setUserData("weapon");
        return body;
    }
    public Texture[] createHealthBar(){
        Texture backGround = new Texture("HealthBarBackGround.png");
        Texture RealHealth = new Texture ("HealthBarGreen.png");
        Texture[] TextureArr = {backGround,RealHealth};
        return TextureArr;
    }
    public Texture[] createFuelBar(){
        Texture backGround = new Texture("GameFuelBackGround.png");
        Texture RealHealth = new Texture ("GameFuelOrange.png");
        Texture[] TextureArr = {backGround,RealHealth};
        return TextureArr;
    }

    public ImageButton getImageButton(String Path){
        Texture picture = new Texture(Gdx.files.internal(Path));
        TextureRegion TextureRegion = new TextureRegion(picture);

        Drawable drawableTextureRegion= new TextureRegionDrawable(TextureRegion);


        ImageButton button = new ImageButton(drawableTextureRegion);
        return button;
    }


}
