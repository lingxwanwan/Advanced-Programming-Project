package GamePlay;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;

import java.util.ArrayList;
import java.util.HashMap;

public class Tanks extends Sprite {
    private String name;
    public float radiusOfDamage;
    public Texture tankImage;
    public float Fuel ;
    public static final float AmountToDecFuel = 20;

    public HashMap<String,Weapon> TankWeapons  = new HashMap<>();
    public Weapon CurrentWeapon;
    public Tanks(String Name){
        this.name = Name;
        this.Fuel = 200;
    }
    public String getName(){
        return this.name;
    }
    public void DecFuel(float amount){
        this.setFuel(this.getFuel()-amount);
    }
    public float getFuel(){
        return this.Fuel;
    }
    public void  ResetFuel(){
        this.Fuel = 200;
    }
    public void setFuel(float val){
        if (val>=0){
            this.Fuel = val;
        }
        else{
            this.Fuel = 0;
        }

    }
}
class Abraham extends Tanks{
    public Abraham(){
        super("Abraham");
        tankImage = new Texture(Gdx.files.internal("AbramsTank.png"));
        TankWeapons.put("VerticalSlam",new Weapon("VerticalSlam",5,1,5,"VerticalSlam.png"));
        CurrentWeapon  = TankWeapons.get("VerticalSlam");
    }
}
class Frost extends Tanks{
    public Frost(){
        super("Frost");
        tankImage = new Texture("Frost.png");
        TankWeapons.put("VerticalSlam",new Weapon("VerticalSlam",5,1,5,"VerticalSlam.png"));
        CurrentWeapon  = TankWeapons.get("VerticalSlam");
    }

}
class Buratino extends Tanks{
    public Buratino(){
        super("Buratino");
        tankImage = new Texture("Buratino.png");
        TankWeapons.put("VerticalSlam",new VerticalSlam());
        CurrentWeapon  = TankWeapons.get("VerticalSlam");
    }
}