package GamePlay;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Actor;

import java.nio.file.Watchable;

interface WeaponInter{
    public String getName();
    public void setName();

    public float getradiusOfImpact();
    public void setradiusOfImpact();

    public int getLevel();
    public void setLevel();

    public int getMaxLevel();
    public void setMaxLevel();

    public Texture getweaponImage();
    public void setweaponImage();

    public float getdamage();
    public void setdamage();
    public void fire();
}

public class Weapon implements  WeaponInter{
    private String Name;
    private float radiusOfImpact;
    private int Level;
    private int MaxLevel;
    private Texture weaponImage;
    private float damage;

    public Weapon(String Name,float radiusOfImpact,int level,int Maxlevel,String ImagePath) {
        this.Name = Name;
        this.radiusOfImpact = radiusOfImpact;
        this.Level = level;
        this.MaxLevel = Maxlevel;
        this.weaponImage  = new Texture(Gdx.files.internal(ImagePath));
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public void setName() {

    }

    @Override
    public float getradiusOfImpact() {
        return 0;
    }

    @Override
    public void setradiusOfImpact() {

    }

    @Override
    public int getLevel() {
        return 0;
    }

    @Override
    public void setLevel() {

    }

    @Override
    public int getMaxLevel() {
        return 0;
    }

    @Override
    public void setMaxLevel() {

    }

    @Override
    public Texture getweaponImage() {
        return this.weaponImage;
    }

    @Override
    public void setweaponImage() {

    }

    @Override
    public float getdamage() {
        return 0;
    }

    @Override
    public void setdamage() {

    }
    @Override
    public void fire(){

    }

}
class VerticalSlam extends Weapon{
    private static int level = 1;
    private static  float RadiusOfImpact = 5;
    private static String ImagePath = "VerticalSlam.png";

    public VerticalSlam(){
        super("VerticalSlam",RadiusOfImpact,level,5,ImagePath);
    }
}

