package GamePlay;

import com.badlogic.gdx.graphics.g2d.Sprite;

import java.util.ArrayList;
import java.util.HashMap;

public class AllWeapons extends Sprite {
    public static  HashMap<String,Weapon> WeaponList = new HashMap<>();

    private Weapon VerticalSlam ;

    public AllWeapons (){
        VerticalSlam  = new VerticalSlam();
        WeaponList.put("VerticalSlam",VerticalSlam);
    }

    public HashMap<String, Weapon> getWeaponList(){
        return WeaponList;
    }

}
