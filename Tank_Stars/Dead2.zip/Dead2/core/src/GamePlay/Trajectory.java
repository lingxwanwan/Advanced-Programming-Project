package GamePlay;

import com.badlogic.gdx.graphics.Texture;

import java.util.HashMap;

public class Trajectory {

    public static int FirstPlayerpower = 50;
    public static int FirstPlayerangle = 0;
    public static int SecondPlayerpower = 50;
    public static int SecondPlayerangle = 0;

}
