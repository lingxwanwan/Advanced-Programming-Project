package GamePlay;



public class Modes {
    Player FirstPlayer;
    Player SecondPlayer;
    String ModeName;
}
