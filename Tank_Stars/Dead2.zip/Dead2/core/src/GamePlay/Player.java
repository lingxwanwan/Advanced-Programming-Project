package GamePlay;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.physics.box2d.*;

import java.util.ArrayList;

interface  PlayerInterface {
    public Tanks getTanks();
    public Tanks setTanks(Tanks tanks);

    public void decHealth(float value);
    public void setHealth(float health);
    public float getHealth();

    public Boolean getWiningStatus();
    public void setWiningStatus(Boolean value);



}
public class Player extends Sprite implements PlayerInterface {
    private Tanks tanks;
    private float health;  // in units (I have defined it);
    private Boolean WiningStatus;
    public Player(Tanks tanks){
        this.tanks = tanks;
        this.health = 400;
    }

    public Tanks getTanks(){
        return this.tanks;
    }

    @Override
    public Tanks setTanks(Tanks tanks) {
        return null;
    }

    @Override
    public void decHealth(float value) {

    }

    @Override
    public void setHealth(float health) {
        if (health<0){
            this.health  = 0;
        }
        else{
            this.health = health;
        }

    }
    public void DecHealth(float amount){
        setHealth(this.getHealth()-amount);
    }

    @Override
    public float getHealth() {
        return this.health;
    }

    @Override
    public Boolean getWiningStatus() {
        return null;
    }

    @Override
    public void setWiningStatus(Boolean value) {

    }
    public ArrayList<Float> update(Body body){
        ArrayList<Float> arr = new ArrayList<>();
        arr.add(body.getPosition().x-50/2);
        arr.add(body.getPosition().y-10);
        return arr;
    }
}
