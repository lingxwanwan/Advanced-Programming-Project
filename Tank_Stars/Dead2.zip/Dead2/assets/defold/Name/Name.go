embedded_components {
 id: "collisionobject1" 
 type: "collisionobject" 
 data: "collision_shape: \"/Name/Name_1.convexshape\"\n" 
 "type: COLLISION_OBJECT_TYPE_STATIC\n" 
 "mass: 0.0\n" 
 "friction: 0.1\n" 
 "restitution: 0.5\n" 
 "group: \"default\"\n" 
 "mask: \"default\"\n" 
 "linear_damping: 0.0\n" 
 "angular_damping: 0.0\n" 
 "locked_rotation: false\n" 
 "" 
 position { 
     x: 0.0 
     y: 0.0 
     z: 0.0 
 } 
 rotation { 
     x: 0.0 
     y: 0.0 
     z: 0.0 
     w: 1.0 
 } 
} 
embedded_components {
 id: "collisionobject2" 
 type: "collisionobject" 
 data: "collision_shape: \"/Name/Name_2.convexshape\"\n" 
 "type: COLLISION_OBJECT_TYPE_STATIC\n" 
 "mass: 0.0\n" 
 "friction: 0.1\n" 
 "restitution: 0.5\n" 
 "group: \"default\"\n" 
 "mask: \"default\"\n" 
 "linear_damping: 0.0\n" 
 "angular_damping: 0.0\n" 
 "locked_rotation: false\n" 
 "" 
 position { 
     x: 0.0 
     y: 0.0 
     z: 0.0 
 } 
 rotation { 
     x: 0.0 
     y: 0.0 
     z: 0.0 
     w: 1.0 
 } 
} 
embedded_components {
 id: "collisionobject3" 
 type: "collisionobject" 
 data: "collision_shape: \"/Name/Name_3.convexshape\"\n" 
 "type: COLLISION_OBJECT_TYPE_STATIC\n" 
 "mass: 0.0\n" 
 "friction: 0.1\n" 
 "restitution: 0.5\n" 
 "group: \"default\"\n" 
 "mask: \"default\"\n" 
 "linear_damping: 0.0\n" 
 "angular_damping: 0.0\n" 
 "locked_rotation: false\n" 
 "" 
 position { 
     x: 0.0 
     y: 0.0 
     z: 0.0 
 } 
 rotation { 
     x: 0.0 
     y: 0.0 
     z: 0.0 
     w: 1.0 
 } 
} 
embedded_components {
 id: "collisionobject4" 
 type: "collisionobject" 
 data: "collision_shape: \"/Name/Name_4.convexshape\"\n" 
 "type: COLLISION_OBJECT_TYPE_STATIC\n" 
 "mass: 0.0\n" 
 "friction: 0.1\n" 
 "restitution: 0.5\n" 
 "group: \"default\"\n" 
 "mask: \"default\"\n" 
 "linear_damping: 0.0\n" 
 "angular_damping: 0.0\n" 
 "locked_rotation: false\n" 
 "" 
 position { 
     x: 0.0 
     y: 0.0 
     z: 0.0 
 } 
 rotation { 
     x: 0.0 
     y: 0.0 
     z: 0.0 
     w: 1.0 
 } 
} 
